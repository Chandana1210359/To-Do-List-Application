# 📝 To-Do List Application (Python CLI)

## 📌 Description

A simple command-line **To-Do List Application** built using **Python**, allowing users to:
- Add tasks
- View all tasks
- Mark tasks as completed

It uses **classes** to represent tasks and conditional statements for control flow.

---

## 🛠️ Skills Demonstrated

- Basic Python Programming
- Object-Oriented Programming (OOP)
- Data Structures (List & Class)
- Conditional Statements
- CLI interaction

---

## 🚀 How to Run

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/to-do-list-app.git
cd to-do-list-app
```

### 2. Run the App
```bash
python main.py
```

---

## ✅ Features

- 📌 Add new tasks
- ✅ Mark tasks as completed
- 📋 View task list with status

---

## 🧑‍💻 Sample Run

```
To-Do List Application
1. Add Task
2. View Tasks
3. Complete Task
4. Exit
```

---

## 📃 License

This project is licensed under the MIT License.